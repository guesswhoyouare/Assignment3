import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;


public class HtmlThread2014302580199 implements Runnable{
	private Resource2014302580199 r;
	public static int count = 0;
	HtmlThread2014302580199(Resource2014302580199 r)
	{
		this.r = r;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		String URLx = "http://staff.whu.edu.cn/";
		Document doc;
		Elements contents = null;
	//	long t1 = System.currentTimeMillis();
		try {
			doc = Jsoup.connect(URLx).get();
			contents = doc.select("p").select("a[href]");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		for(int i =0;i<100;i++)
		{
			r.getHtml(i,contents);
			count++;
		}
	}
}