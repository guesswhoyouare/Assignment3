import java.sql.Connection;


public class DataThread2014302580199 implements Runnable {
	private Resource2014302580199 r;
	private Connection con;
	DataThread2014302580199(Resource2014302580199 r)
	{
		this.r = r;
	}
	public void run()
	{
		for(int i =0;i<100;i++)
		{
			r.getData(i);

		}
	}
}
