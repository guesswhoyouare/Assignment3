import org.jsoup.select.Elements;


public class Resource2014302580199 {
	public synchronized void getHtml( int i ,Elements contents)
	{

		GetHtml2014302580199 html = new GetHtml2014302580199();
		html.html(i,contents);

		notifyAll();
	}
	
	
	
	public synchronized void getData( int i)
	{

		while(i>=HtmlThread2014302580199.count)
		{

			try{this.wait();}
				catch(InterruptedException e)
				{}
		}

		
		GetData2014302580199 data = new GetData2014302580199();
		data.data(i);

	//	flag = false;
		notifyAll();
	}
}
