import java.io.File;

import org.jsoup.select.Elements;


public class GetHtml2014302580199 {
	public void html( int i , Elements contents)
	{
		String URL = contents.get(i).absUrl("href").replace(" ", "%20");
		HttpRequest response = HttpRequest.get(URL);
		
		String fileName = "test" + i+ ".html"; 
		//����������ļ���
		File fName = new File(fileName);
		//���浽�ļ���
		response.receive(fName);
		

	//	System.out.println(contents.toString());
		
	}
}
