import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;


public class GetData2014302580199 {
	private String [] str = new String[100];
	private Connection con;
	
 	public  void data( int i ) 
 	{
 		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://127.0.0.1:3306/sakila";
		String username = "root";
		String password = "test";
		try {
			Class.forName(driver);
			try {
				con = DriverManager.getConnection(url,username,password);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//��������mysql���ݿ������
		//��������
		
 			File file = new File("test"+i+".html");
 	 	 	Document doc;
			try {
				doc = Jsoup.parse(file,"utf-8");
				Elements contents = 
	 	 	 			doc.select("[class=details col-md-10 col-sm-9 col-xs-7]");
	 	 	 	str[i] = contents.toString();
	 	 		
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
 	 	 
			try {
				insert(i);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		

 	}
 	
 	
 	public String GetName( int i ) throws IOException 
	{
 		Pattern pattern = Pattern.compile("<h3.*?</h3>");
		Matcher matcher = pattern.matcher(str[i]);
		
		while(matcher.find())
		{
			if(!matcher.group().replaceAll("<.*?>", "").trim().isEmpty())
			return matcher.group().replaceAll("<.*?>", "");
			else
				return null;
		}
		return null;
	}
	
	public String GetPersonalProfile( int i )
	{
		Pattern pattern = Pattern.compile("<p>.*?<br>");
		Matcher matcher = pattern.matcher(str[i]);
		while(matcher.find())
		{
			return matcher.group().replaceAll("<.*?>", "");
		}
		return null;
		
	}
	
	public String GetEmail( int i) 
	{
		Pattern pattern = Pattern.compile("\\w*@(\\w|\\.)*");
		Matcher matcher = pattern.matcher(str[i]);
		while(matcher.find())
		{
			return matcher.group().replaceAll("<.*?>", "");
		}
		return null;
	}
	
	public String GetTel( int i) 
	{
		Pattern pattern = Pattern.compile("[0-9]{3}\\-*[0-9]{8}");
		Matcher matcher = pattern.matcher(str[i]);
		while(matcher.find())
		{
			return matcher.group().replaceAll("<.*?>", "");
		}
		return null;
	}
	
	public String GetResearchDirection( int i )
	{
		Pattern pattern = Pattern.compile("<br>.*?<br>");
		Matcher matcher = pattern.matcher(str[i]);
		while(matcher.find())
		{
			return matcher.group().replaceAll("<.*?>", "");
		}
		return null;
	}
 	
	
	private void insert( int i) throws IOException, SQLException
	{
		String insert = "insert teacherinformation2 values(?,?,?,?,?)";
			
			PreparedStatement pstmt = con.prepareStatement(insert);
			if( null == GetName(i))
			{
				return;
			}
			pstmt.setString(1, GetName(i));
		//	System.out.println(GetName(i));
			pstmt.setString(2, GetPersonalProfile(i));
		//	System.out.println(GetPersonalProfile(i));
			pstmt.setString(3, GetEmail(i));
		//	System.out.println(GetEmail(i));
			pstmt.setString(4, GetTel(i));
		//	System.out.println(GetTel(i));
			pstmt.setString(5, GetResearchDirection(i));
		//	System.out.println(GetResearchDirection(i));
		//	System.out.println(i);
			pstmt.executeUpdate();
			pstmt.close();
	
		
		
	}

}
