import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

 

public class Main2014302580199 {

	public static void main(String[] args) throws IOException, ClassNotFoundException, SQLException, InterruptedException {
		// TODO Auto-generated method stub

		

		//���
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://127.0.0.1:3306/sakila";
		String username = "root";
		String password = "test";
				
		Class.forName(driver);//��������mysql���ݿ������
		//��������
		Connection con = DriverManager.getConnection(url,username,password);
		
		String delete = "delete from teacherinformation2";
		
		PreparedStatement pstmt1 = con.prepareStatement(delete);
		pstmt1.executeUpdate();
		pstmt1.close();
		
		//System.out.println("1");
		//���߳�
		Resource2014302580199 r = new Resource2014302580199();
		HtmlThread2014302580199 html = new HtmlThread2014302580199(r);
		DataThread2014302580199 data = new DataThread2014302580199(r);
		
		//System.out.println("2");
		Thread tHtml = new Thread(html);
		Thread tData = new Thread(data);
		long startTime = System.currentTimeMillis();
	
		tHtml.start();
		tData.start();
		
		tHtml.join();
		tData.join();
		//System.out.println("3");
		long endTime = System.currentTimeMillis();
		
		long time = endTime -startTime;
		
		System.out.println("���߳�ʱ�䣺"+time);
		
		
		
		//������ݿ�
		PreparedStatement pstmt2 = con.prepareStatement(delete);
		pstmt2.executeUpdate();
		pstmt2.close();
		con.close();
		
		//���߳�
		long startTime2 = System.currentTimeMillis();
		String URLx = "http://staff.whu.edu.cn/";
		Document doc;
		doc = Jsoup.connect(URLx).get();
		Elements contents = doc.select("p").select("a[href]");
		GetHtml2014302580199 getHtml = new GetHtml2014302580199();
		GetData2014302580199 getData = new GetData2014302580199();
		
		
		for(int i =0;i<100;i++)
		{
			getHtml.html(i, contents);
			getData.data(i ); 
		}
		long endTime2 = System.currentTimeMillis();
		
		long time2 = endTime2 -startTime2;
		
		System.out.println("���߳�ʱ�䣺"+time2);
		
		
		
		
	
		
	
	}

}
